package my.pharmacy;
 
public class Menu {
  
    public double price;
    public String nameOfItem;
    public String discription;
 
  
    public Menu(){
      
    }
 
    public Menu(double price, String nameOfItem, String discription) {
        this.price = price;
        this.nameOfItem = nameOfItem;
        this.discription = discription;
    
    }
 
    public void setPrice(double price) {
        this.price = price;
    }
 
    public void setNameOfItem(String nameOfItem) {
        this.nameOfItem = nameOfItem;
    }
 
    public void setDiscription(String discription) {
        this.discription = discription;
    }
 
 
    public double getPrice() {
        return price;
    }
 
    public String getNameOfItem() {
        return nameOfItem;
    }
 
    public String getDiscription() {
        return discription;
    }
 
   
    public void display(){
    
        System.out.println(this.nameOfItem +"\t "+this.discription+" \t "+this.price);
        
       
    }
}