package my.pharmacy;
 
public class Customer extends User {
  
}
